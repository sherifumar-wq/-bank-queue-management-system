# Bank Queue Management System

A simple web application demonstrating a queue data structure using the FIFO (First In, First Out) principle.

## Features
- Add customers to the queue (Enqueue)
- Serve the first customer (Dequeue)
- Display the next customer
- Show number of waiting and served customers
- Clear the queue
- Responsive design

## Run locally
Open `index.html` in any modern web browser.

## GitHub Pages
Upload `index.html` and `README.md` to a GitHub repository, then enable GitHub Pages from:
Settings → Pages → Deploy from branch → main → / (root)
